# Lyric ML Function Call example (Parameter Extraction)

## Function call Time
completed in 1726.76425ms

## Function call Chat History
```json
 [
  {
    "content": "\nYou are an AI Human Resources assistant designed to retrieve Healthcare Benefit Coverage information based on user queries.\n\nWhen processing user queries, please adhere to the following guidelines:\n\n1. **Named Benefit Areas**: If the query specifies benefit area names, select up to 3 closest semantic matches for each `standardBenefitArea` without seeking clarification. \n   - *Example 1*: For the query \"What is my child coverage?\", use up to 3 `standardBenefitAreaName` that includes \"child\" for `standardBenefitAreaNames` and its corresponding `standardBenefitArea` for the `standardBenefitAreas`.\n   - *Example 2*: For the query \"What is my spouse coverage?\", use up to 3 `standardBenefitAreaName` that includes \"spouse\" for `standardBenefitAreaNames` and its corresponding `standardBenefitArea` for the `standardBenefitAreas`.\n   - *Example 3*: For the query \"What is my dental?\", use up to 3 `standardBenefitAreaName` that includes \"dental\" (e.g., \"Dental\" and \"Additional Dental\") for `standardBenefitAreaNames` and its corresponding `standardBenefitArea` for the `standardBenefitAreas`.\n   - *Example 4*: For the query \"What is my long term disability?\", use up to 3 `standardBenefitAreaName` that either includes words from \"long term disability\" or \"LTD\" (acronym) for `standardBenefitAreaNames` and its corresponding `standardBenefitArea` for the `standardBenefitAreas`.\n\n2. **General Benefit Queries**: If the query does not specify benefit area names, utilize all available `standardBenefitAreas` without seeking clarification. \n   - *Example*: For the query \"What is my coverage?\", use all available `standardBenefitAreaName` entries.\n\n3. **Standard Benefit Area Names**: In this context, \"medical\" refers to a Standard Benefit Area that includes names specifically related to medical services, such as \"Primary Medical\" or \"Medical.\" Only plans with names that contain \"Medical\" will match this category. For example, \"Medical\" and \"Primary Medical\" match, while \"Dental\" or \"Long-term Disability\" do not. \n   - *Example*: For the query \"What is my medical benefit?\", use `standardBenefitAreaName` which has \"Medical\" in it for the `standardBenefitAreaNames` and its corresponding `standardBenefitArea` for the `standardBenefitAreas`.\n\n4. **Parameter Usage**:\n   - For `standardBenefitAreas`, use the `standardBenefitArea` code (e.g., use \"MEDICAL\" instead of \"Primary Medical\").\n   - For `standardBenefitAreaNames`, use the `standardBenefitAreaName` (e.g., use \"Primary Medical\" instead of \"MEDICAL\").\n\nBelow is the mapping of `standardBenefitArea` to `standardBenefitAreaName`:\n\n|   standardBenefitArea   |   standardBenefitAreaName   |\n|:-----------------------:|:---------------------------:|\n| LTD                     | LTD                         |\n| MEDICAL                 | Primary Medical             |\n",
    "role": "system"
  },
  {
    "content": "who is under my medical?",
    "role": "user"
  }
]
```

## Function definition

```json
 {
  "description": "Get coverage plans for the associate",
  "name": "get_coverage_plans_for_associate",
  "parameters": {
    "properties": {
      "isSpecified": {
        "description": "This parameter determines whether the user query mentioned at least one possible names of standard benefit areas (standardBenefitAreaName). \n1. If the user query mentioned at least one standard benefit area, set this parameter to `true`. Example: \"what is my dental and medical?\", the value should be `true`.; \n2. otherwise, set it to `false`. Example: \"what is my benefits?\", the value should be `false`.",
        "name": "isSpecified",
        "type": "boolean"
      },
      "standardBenefitAreaNames": {
        "description": "This parameter specifies the names of standard benefit areas (i.e. 'standardBenefitAreaName'). The value must be formatted according to the following rules:\n1. **Single Item**: If there is only one item, use that item directly.\n   - **Example**: `Dependent AD&D`\n2. **Multiple Items**: If there are multiple items, list them in a sentence, separating each item with a comma and using \"and\" before the last item.\n   - **Example**: `item1, item2, and item3`\n3. **Default Value**: If no items are specified, use all the standard benefit area names available in the system prompt context.\n",
        "name": "standardBenefitAreaNames",
        "type": "string"
      },
      "standardBenefitAreas": {
        "description": "This parameter specifies the standard benefit areas (i.e. 'standardBenefitArea') and will be used as a field value in a Solr query. The value must be URL-encoded according to the following guidelines:\n1. **Single Item:**\n   - If only one item is provided, enclose it in double quotes and then encode it.\n   - **Example:** \n     - Input: `\"item\"`\n     - Encoded Value: `%22item%22`\n2. **Multiple Items:**\n   - When multiple items are specified, follow these steps:\n     - Enclose each item in double quotes.\n     - Separate the items with the keyword `OR`.\n     - Enclose the entire expression in parentheses.\n     - Finally, encode the complete expression.\n   - **Example:** \n     - Input: `(\"item1\" OR \"item2\" OR \"item3\")`\n     - Encoded Value: `%28%22item1%22%20OR%20%22item2%22%20OR%20%22item3%22%29`\n3. **Default Value:**\n   - If no items are specified, the default value should be an asterisk (`*`).\n   - **Example:** \n     - Default Encoded Value: `*`\n",
        "name": "standardBenefitAreas",
        "type": "string"
      }
    },
    "required": [
      "standardBenefitAreas",
      "standardBenefitAreaNames",
      "isSpecified"
    ],
    "type": "object"
  }
}
```

## Function call result

```json
 {
  "arguments": "{\"isSpecified\":false,\"standardBenefitAreaNames\":\"Primary Medical, and Medical\",\"standardBenefitAreas\":\"*\"}",
  "name": "get_coverage_plans_for_associate"
}
```